#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN = 110;

struct bigdata
{
	int dat[110];
	int len;
	void clear()
	{
		memset(dat, 0, sizeof(dat));
		len = 0;
	}
	int operator < (const bigdata &o) const
	{
		if (len > o.len)
			return 0;
		if (len < o.len)
			return 1;
		for(int i = len; i >= 1; i--)
			if (dat[i] < o.dat[i])
				return 1;
			else
			if (dat[i] > o.dat[i])
				return 0;
		return 0;
	}
	bigdata operator *(const bigdata o)
	{
		bigdata res;
		res.clear();
		res.len = o.len + len - 1;
		for(int i = 1; i <= len; i++)
			if (dat[i])
				for(int j = 1; j <= o.len; j++)
					if (o.dat[j])
					{
						res.dat[i + j - 1] += dat[i] * o.dat[j];
					}
		return res;
	}
	void print()
	{
		for(int i = len; i >= 1; i--)
			printf("%d", dat[i]);
		printf("\n");
	}
}fair[43000], read, L, R, cmp;
int all = 0;

bigdata now;

void dfs(int dep, int cnt, int tot)
{
	if (dep > (tot + 1) / 2)
	{
		for(int i = 1; i <= (tot + 1) / 2; i++)
			now.dat[tot - i + 1] = now.dat[i];
		now.len = tot;
		fair[++all] = now;
		//for(int i = tot; i >= 1; i--)
		//	printf("%d", now.dat[i]);
		//printf("\n");
		return ;
	}
	int base = 2;
	if (tot % 2 == 1 && dep * 2 == tot + 1)
		base = 1;
	for(int i = 0; i < 3; i++)
	if (cnt + base * i * i <= 9)
	{
		if (i == 0 && dep == 1)
			continue;
		now.dat[dep] = i;
		dfs(dep + 1, cnt + base * i * i, tot);
	} else
		break;
}

char re[MAXN];

void READ()
{
	read.clear();
	scanf("%s", re + 1);
	int l = strlen(re + 1);
	for(int i = 1; i <= l; i++)
		read.dat[l - i + 1] = re[i] - '0';
	read.len = l;
}

int main()
{
	freopen("C-large-2.in", "r", stdin); freopen("C-large-2.out", "w", stdout);
	all = 0;
	for(int i = 1; i <= 50; i++)
	{
		now.clear();
		dfs(1, 0, i);
	//	printf("times = %d\n", i);
	}
	fair[++all].len = 1;
	fair[all].dat[1] = 3;
	sort(fair + 1, fair + all + 1);
	//printf("all = %d\n", all);
	//for(int i = 1; i <= 10; i++)
	//	fair[i].print();
	int T;
	scanf("%d\n", &T);
	for(int t = 1; t <= T; t++)
	{
		READ();
		L = read;
		READ();
		R = read;
		int al, ar, l, r;
		l = 1, r = all;
		while(l < r)
		{
			int mid = (l + r) / 2;
			cmp = (fair[mid] * fair[mid]);
			if (cmp < L)
				l = mid + 1;
			else
				r = mid;
		}
		al = l;
		l = 1, r = all;
		while(l < r)
		{
			int mid = (l + r) / 2 + 1;
			cmp = (fair[mid] * fair[mid]);
			if (R < cmp)
				r = mid - 1;
			else
				l = mid;
		}
		ar = r;
		printf("Case #%d: ", t);
		printf("%d\n", ar - al + 1);
	}
	return 0;
}
